print('Bienvenido a la graduacion del TechGround')
identificacion = input('Ingrese su identificacion =>')

if identificacion == '115260864':
    print('Buen trabajo Pablo, te has graduado')
else:
    print('Lo sentimo, no tenemos registrado ningun graduando con esa identificacion')
