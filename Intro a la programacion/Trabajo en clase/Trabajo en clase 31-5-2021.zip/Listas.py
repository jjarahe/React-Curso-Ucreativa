#Listas 
amigos = ["Pablo", "Luis", "Carlos"]


#Las listas tienen ventajas
#Se pueden agregar datos a la lista usando funciones
#por ejemplo el .append(), .len(), .remove()
amigos.append('Pedro')
print(amigos)
print(f'Yo tengo {len(amigos)} amigos')

amigos.remove('Pedro')
print(f'Pedro ya no es mi amigo, ahora tengo {len(amigos)} amigos')

frutas = ['Mango','Banano','Pina']

amigos.append(frutas) #lista de listas

print(amigos)
